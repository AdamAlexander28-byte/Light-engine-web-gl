# .LIGHT PROTOCOL — AIVisionEngine (WebGL+ Build)

**Swedish Dawn Boot** — GPU-heavy intro with:
- Fragment shader gradient + diagonal sweep + scanlines
- **GPU particle field** (80 particles) with faux bloom
- **3D-style logo swirl** (SDF shading)
- Glass panel reflection + shimmering title text

Boot lasts **~4 seconds** then auto-starts the engine. PWA-enabled and iPhone 16 Plus–ready.

## Deploy (GitHub Pages)
1. Create a repo and place these files at the root.
2. Settings → Pages → Deploy from **Main** → **/(root)**.
3. Open the published URL in **Safari** on iPhone.

## Deploy (Netlify)
1. Drag the unzipped folder into Netlify, or use `netlify deploy`.
2. Open on iPhone Safari.

## Install (iPhone)
- Safari → **Share** → **Add to Home Screen** → Launch for full-screen mode.

## Offline
Service worker caches core assets on first load. To force an update, change the `CACHE_NAME` in `service-worker.js`.

## Customise
- Boot time: search for `4000` ms in `index.html`.
- Shader visuals: edit the fragment shader inside `index.html` (`const fs = \``).
- Title: find "Initialising AIVision Engine".

**Created by Adam Alexander — .LIGHT Protocol**