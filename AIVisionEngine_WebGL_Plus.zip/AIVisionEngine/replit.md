# .LIGHT — Swedish Dawn

## Overview
A bright, glassy, and performance-optimized visual runtime for the .LIGHT protocol featuring:
- **Shield**: Multi-ring absorption system with hit detection
- **Switch-Field**: 360° transistor halo visualization
- **Angle Zoom**: 0-9 channel magnified sector view
- **Real-time HUD**: Reserve, Thermal, and Mode metrics
- **Modular Activation**: Runtime feature unlocking system
- **Settings Persistence**: localStorage-based configuration
- **Keyboard Shortcuts**: Full keyboard control support
- **PWA-Ready**: Progressive Web App capabilities

## Recent Changes
**2025-01-19**: Complete React implementation
- Built all TypeScript interfaces and types
- Configured Swedish Dawn design system (glass morphism, sky gradients)
- Implemented all components: LightLoader, HUDPanel, ShieldControls, ModularActivation, LayerStack
- Created canvas visualizations: ShieldCanvas, SwitchFieldCanvas, AngleZoomCanvas
- Added TextRuntime for transistor lanes
- Implemented requestAnimationFrame animation loop
- Added keyboard shortcuts and tap gloss effects
- Settings persistence via localStorage

## User Preferences
- **Visual Style**: Swedish Dawn aesthetic with bright, glassy panels and subtle animations
- **Design System**: Glass morphism with backdrop filters, soft shadows, and dawn-inspired gradients
- **Performance**: Client-side rendering with optimized canvas animations
- **Interactions**: Tap gloss effects on panels, smooth transitions, keyboard shortcuts

## Project Architecture

### Frontend Stack
- **React 18** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS** for styling
- **Canvas API** for visualizations
- **wouter** for routing
- **localStorage** for persistence

### Design System
- **Colors**: 
  - Sky gradients: #edf4ff → #ffffff
  - Glass panels: rgba(255,255,255,0.35) with 18px blur
  - Accent: rgb(140, 201, 255)
  - Status: OK (green), Warn (orange), Crit (red)
- **Typography**: Segoe UI, system fonts
- **Effects**: Backdrop blur, tap gloss, sunrise loader

### Component Structure
```
client/src/
├── components/
│   ├── LightLoader.tsx          # Sunrise animation loader
│   ├── GlassPanel.tsx            # Reusable glass morphism container
│   ├── HUDPanel.tsx              # Reserve/Thermal/Mode metrics
│   ├── ShieldControls.tsx        # Scale, layers, opacity, hit rate
│   ├── ModularActivation.tsx     # Module activation buttons
│   ├── LayerStack.tsx            # Layer toggles + quality
│   ├── ShieldCanvas.tsx          # Multi-ring absorption viz
│   ├── SwitchFieldCanvas.tsx     # 360° transistor halo
│   ├── AngleZoomCanvas.tsx       # Channel sector view
│   └── TextRuntime.tsx           # Transistor lanes output
├── hooks/
│   └── useLightState.ts          # State management + localStorage
└── pages/
    ├── Home.tsx                  # Route entry
    └── LightViz.tsx              # Main visualization component
```

### State Management
- Custom React hooks with localStorage persistence
- requestAnimationFrame-driven animation loop
- Real-time canvas rendering updates
- Keyboard event handling

### Keyboard Shortcuts
- **Space**: Play/Pause
- **1-3**: Toggle layers (Shield, Switch-Field, Angle Zoom)
- **Z/X/C**: Quality settings (Base, Extra Zoom, Extra Range)
- **+/-**: Adjust layer count
- **[/]**: Hit rate control
- **O**: Toggle Low-Power / Full mode

## Canvas Visualizations

### Shield (Multi-Ring Absorption)
- Dynamic ring system based on layer count
- Hit spawning and collision detection
- Reserve accumulation on absorption
- Adaptive radius based on scale (meter/planetary)
- Core gradient responds to thermal state

### Switch-Field (360° Transistor Halo)
- Circular transistor ring with jitter animation
- Quality modes: base (360 points) vs range (540 points, 2 rings)
- Radial spokes with rotation
- Hue varies with thermal, brightness with reserve

### Angle Zoom (0-9 Channels)
- Rotating sector view with magnification
- 10 micro-channels with AI remapping every 15 ticks
- Quality modes: base (16°) vs zoom (28° sector)
- Grid background for reference

## Development Notes
- No backend API needed - fully client-side application
- State persists via localStorage across sessions
- Animations use requestAnimationFrame for smooth 60fps
- Responsive design: 3-column desktop → stacked mobile
- Glass morphism effects optimized for performance

## Deployment
- Express server serves static files
- Vite handles development hot reload
- Production build via `npm run build`
- PWA manifest ready for offline capability

## Future Enhancements
- WebGL shader implementation for GPU acceleration
- Service worker registration for offline mode
- Export/screenshot functionality
- Additional module types
- Preset configurations
