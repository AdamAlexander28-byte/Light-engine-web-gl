# .LIGHT Swedish Dawn — Design Guidelines

## Design Approach
**System**: Custom Glass Morphism Design System with Scientific Data Visualization Focus
**Rationale**: This is a utility-focused, data-visualization application requiring clarity, precision, and real-time feedback. The "Swedish Dawn" aesthetic provides a bright, calming foundation for intensive data monitoring.

## Core Design Principles
1. **Glass Clarity**: Layered transparency creates depth while maintaining readability
2. **Minimal Distraction**: Animations serve function, not decoration
3. **Scientific Precision**: Every visual element communicates state or data
4. **Dawn Light Quality**: Soft gradients and gentle shadows mimic early morning light

## Color Palette

### Light Mode (Primary)
- **Background Gradient**: 237 94% 99% (top) → 0 0% 100% (bottom)
- **Panel Glass**: rgba(255,255,255,0.35) with 18px blur
- **Accent Primary**: 200 100% 76% (bright sky blue)
- **Text Primary**: 210 48% 12% (deep blue-black)
- **Text Muted**: rgba(0,0,0,0.55)

### Status Colors
- **OK/Healthy**: 152 55% 49% (fresh green)
- **Warning**: 32 100% 64% (warm orange)
- **Critical**: 4 100% 67% (soft red)

### Canvas Visualizations
- **Shield Core Hue**: 170-210 (varies with thermal state)
- **Shield Rings**: 210 100% 68% at 18-85% opacity
- **Switch-Field**: 170-190 hue, 70% saturation, 45-55% lightness
- **Background Sky**: White to 204 100% 98% gradients

## Typography

### Font Stack
**Primary**: Segoe UI, system-ui, sans-serif
**Monospace**: ui-monospace, Consolas, Monaco, monospace

### Hierarchy
- **H1 (Header)**: 18px, weight 600, 0.05em letter-spacing
- **H3 (Section Headers)**: 16px, weight 600, 6px margins
- **H4 (Subsections)**: 14px, weight 600
- **Body Text**: 14px, default weight
- **Small/Labels**: 12px for legends, captions, metadata
- **Monospace Output**: 12px for data lanes, technical readouts

## Layout System

### Spacing Primitives
**Tailwind Equivalent Units**: 2, 3, 4, 6, 8, 10, 12, 14
- Small gaps/padding: 6-8px
- Medium spacing: 10-12px
- Large section spacing: 14px
- Panel padding: 12px standard

### Grid Structure
**Desktop (>1024px)**: 3-column layout
- Left sidebar: 320px (controls)
- Center: fluid (data lanes)
- Right sidebar: 360px (visualizations)
- Gap: 12px between all columns

**Mobile (<1024px)**: Stack to single column, auto height

## Component Library

### Panels & Containers
- **Border Radius**: 12px for main panels, 10px for nested, 8px for small elements
- **Border**: 1px solid rgba(200,210,230,0.3)
- **Shadow**: 0 8px 30px rgba(0,0,0,0.04)
- **Backdrop Filter**: blur(18px) for main panels, blur(14px) for nested

### Buttons
- **Background**: Accent color (200 100% 76%)
- **Text**: White
- **Padding**: 7px 10px
- **Border Radius**: 8px
- **Hover**: box-shadow 0 6px 18px rgba(140,201,255,0.25)
- **Active**: scale(0.97), opacity 0.85

### Form Controls
- **Range Inputs**: Full width, native styling
- **Select Dropdowns**: Full width, minimal styling
- **Checkboxes**: 12px labels with 8px gap

### Pills (Status Indicators)
- **Padding**: 4px 8px
- **Border**: 1px solid rgba(180,190,210,0.4)
- **Background**: rgba(255,255,255,0.25)
- **Border Radius**: 999px
- **Font Size**: 11px

### Progress Meters
- **Height**: 8px
- **Border Radius**: 6px
- **Background**: rgba(0,0,0,0.06)
- **Bar Transition**: width 0.3s ease, background 0.3s ease

### Canvas Visualizations
- **Dimensions**: Width 100%, Height 160px standard
- **Background**: rgba(255,255,255,0.9)
- **Border Radius**: 8px
- **Rendering**: 2D context with anti-aliasing

## Interactions & Animations

### Tap Gloss Effect
**Implementation**: Linear gradient sweep (120deg) with rgba(255,255,255,0.6) center
**Duration**: 800ms ease transform
**Trigger**: Click on panel elements

### Loader Animation
**Sun Pulse**: 6s infinite ease-in-out opacity 0.7-1.0
**Haze Sweep**: 8s infinite horizontal translation
**Duration**: 2s fade-in, 1s fade-out

### State Transitions
**Smooth Animations**: 0.1-0.3s for hover/active states
**Data Updates**: Immediate (no artificial delays)
**Canvas Refresh**: RequestAnimationFrame driven

### Hover States
**Buttons**: Subtle shadow elevation
**Panels**: No hover effect (tap gloss on click only)

## Accessibility

### Color Contrast
- Text on glass panels maintains 4.5:1 minimum ratio
- Status colors differentiated by both color and position
- Canvas visualizations include text legends

### Keyboard Navigation
- Space: Play/Pause
- 1-3: Toggle layers
- Z/X/C: Quality settings
- +/-: Adjust layer count
- [/]: Hit rate
- O: Power mode

### ARIA Labels
- Sections labeled with aria-label
- Loader uses role="status"
- All controls have accessible labels

## Scrolling Behavior
- **Right Sidebar**: Independent vertical scroll, thin scrollbar (8px)
- **Scrollbar Style**: rgba(140,180,220,0.3-0.4) with 8px radius
- **Left Sidebar**: Auto overflow for controls
- **Center**: Constrained to grid height

## Responsive Breakpoints
**1024px**: Transition from 3-column to stacked single-column layout
**Mobile**: Full-width panels, auto height, vertical scroll enabled

## Special Effects
**Environment Shadow**: Radial gradient overlay from top, subtle depth
**Panel Glass**: Multi-layer transparency with blur creates "dawn window" effect
**No distracting animations**: All motion serves data feedback or state changes

## Images
**Not Applicable**: This is a data visualization tool with procedurally generated canvas graphics. No static imagery required.