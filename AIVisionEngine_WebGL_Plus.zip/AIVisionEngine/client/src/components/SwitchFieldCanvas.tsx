import { useEffect, useRef } from 'react';
import type { LightState } from '@shared/schema';

interface SwitchFieldCanvasProps {
  state: LightState;
}

export function SwitchFieldCanvas({ state }: SwitchFieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = 160;
    };

    resize();
    window.addEventListener('resize', resize);

    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Sky gradient
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, 'rgba(255,255,255,0.95)');
    sky.addColorStop(1, 'rgba(245,250,255,0.9)');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    if (!state.layersOn.switch) return;

    const cx = w * 0.5;
    const cy = h * 0.55;
    const baseR = 36 + state.reserve * 0.28;
    const hue = 190 - state.therm * 20;

    const steps = state.quality === 'range' ? 540 : 360;
    const rings = state.quality === 'range' ? 2 : 1;

    // Transistor ring
    for (let ring = 0; ring < rings; ring++) {
      const ringR = baseR + ring * 18;
      for (let i = 0; i < steps; i++) {
        const theta = (i / steps) * Math.PI * 2;
        const jitter = Math.sin(theta * 4 + state.tickCount * 0.05) * (2 + ring);
        const r = ringR + jitter;
        const x = cx + r * Math.cos(theta);
        const y = cy + r * Math.sin(theta);
        const a = 0.18 + 0.28 * Math.max(0, Math.sin(theta * 2 + state.tickCount * 0.03));
        ctx.fillStyle = `hsla(${hue},70%,55%,${a})`;
        ctx.fillRect(x, y, 1.1, 1.1);
      }
    }

    // Spokes
    const spokes = state.quality === 'zoom' ? 24 : 12;
    ctx.strokeStyle = `hsla(${hue},70%,45%,0.12)`;
    ctx.lineWidth = 1;
    for (let k = 0; k < spokes; k++) {
      const th = (k / spokes) * Math.PI * 2 + state.tickCount * 0.005;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + (baseR + 22) * Math.cos(th), cy + (baseR + 22) * Math.sin(th));
      ctx.stroke();
    }
  }, [state]);

  return (
    <div id="switchBox" className="rounded-[10px] border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass-sm backdrop-blur-glass-sm">
      <canvas 
        ref={canvasRef} 
        id="switchField"
        className="block h-[160px] w-full rounded-lg bg-[rgba(255,255,255,0.9)]"
        data-testid="canvas-switch"
      />
      <div id="switchLegend" className="mt-1.5 text-[11px] leading-relaxed" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
        • 360° transistor halo. Hue ~ thermal; brightness ~ reserve. "Extra Range" adds outer fidelity.
      </div>
    </div>
  );
}
