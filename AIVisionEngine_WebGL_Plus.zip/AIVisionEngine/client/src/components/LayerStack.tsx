import type { LightState } from '@shared/schema';
import { Button } from '@/components/ui/button';

interface LayerStackProps {
  state: LightState;
  onUpdate: (updates: Partial<LightState>) => void;
}

function Pill({ children, testId }: { children: React.ReactNode; testId?: string }) {
  return (
    <span 
      className="ml-auto inline-block rounded-full border border-[rgba(180,190,210,0.4)] bg-[rgba(255,255,255,0.25)] px-2 py-1 text-[11px]" 
      style={{ color: 'rgb(14, 26, 43)' }}
      data-testid={testId}
    >
      {children}
    </span>
  );
}

export function LayerStack({ state, onUpdate }: LayerStackProps) {
  const getQualityLabel = () => {
    switch (state.quality) {
      case 'zoom': return 'Extra Zoom';
      case 'range': return 'Extra Range';
      default: return 'Base';
    }
  };

  return (
    <div
      id="layerStack"
      className="mt-2.5 rounded-[10px] border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass-sm backdrop-blur-glass-sm"
      data-testid="panel-layer-stack"
    >
      <h4 className="m-0 mb-1.5 text-sm font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
        Layer Stack
      </h4>
      
      {/* Shield Checkbox */}
      <label className="mb-1 flex items-center gap-2 text-xs" style={{ color: 'rgb(44, 61, 85)' }}>
        <input
          type="checkbox"
          id="chkShield"
          checked={state.layersOn.shield}
          onChange={(e) => onUpdate({ 
            layersOn: { ...state.layersOn, shield: e.target.checked }
          })}
          data-testid="checkbox-shield"
        />
        Shield (rings)
      </label>

      {/* Switch-Field Checkbox */}
      <label className="mb-1 flex items-center gap-2 text-xs" style={{ color: 'rgb(44, 61, 85)' }}>
        <input
          type="checkbox"
          id="chkSwitch"
          checked={state.layersOn.switch}
          onChange={(e) => onUpdate({ 
            layersOn: { ...state.layersOn, switch: e.target.checked }
          })}
          data-testid="checkbox-switch"
        />
        Switch-Field (360°)
      </label>

      {/* Zoom Checkbox */}
      <label className="mb-1 flex items-center gap-2 text-xs" style={{ color: 'rgb(44, 61, 85)' }}>
        <input
          type="checkbox"
          id="chkZoom"
          checked={state.layersOn.zoom}
          onChange={(e) => onUpdate({ 
            layersOn: { ...state.layersOn, zoom: e.target.checked }
          })}
          data-testid="checkbox-zoom"
        />
        Angle Zoom (0–9 channels)
      </label>

      {/* Quality Row */}
      <div id="qualityRow" className="mt-2 flex gap-2">
        <Button
          onClick={() => onUpdate({ quality: 'base' })}
          size="sm"
          className="text-xs text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          title="Base (Z)"
          data-testid="button-quality-base"
        >
          Base
        </Button>
        <Button
          onClick={() => onUpdate({ quality: 'zoom' })}
          size="sm"
          className="text-xs text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          title="Extra Zoom (X)"
          data-testid="button-quality-zoom"
        >
          Extra Zoom
        </Button>
        <Button
          onClick={() => onUpdate({ quality: 'range' })}
          size="sm"
          className="text-xs text-white"
          style={{ background: 'rgb(140, 201, 255)', borderColor: 'rgb(120, 181, 235)' }}
          title="Extra Range (C)"
          data-testid="button-quality-range"
        >
          Extra Range
        </Button>
        <Pill testId="text-quality">{getQualityLabel()}</Pill>
      </div>
    </div>
  );
}
