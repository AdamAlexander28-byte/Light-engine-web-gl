import { useEffect, useRef } from 'react';
import type { LightState, Hit } from '@shared/schema';

interface ShieldCanvasProps {
  state: LightState;
  hits: Hit[];
  onHitsUpdate: (hits: Hit[]) => void;
}

export function ShieldCanvas({ state, hits, onHitsUpdate }: ShieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const scaleRadius = (base: number) => {
    return state.scale === 'meter' ? base : base * 1.8;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = 160;
    };

    resize();
    window.addEventListener('resize', resize);

    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w * 0.5;
    const cy = h * 0.6;

    ctx.clearRect(0, 0, w, h);

    // Sky gradient
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, 'rgba(255,255,255,0.95)');
    sky.addColorStop(1, 'rgba(240,247,255,0.85)');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    if (!state.layersOn.shield) return;

    // Core
    const coreR = scaleRadius(14 + state.reserve / 18);
    const hue = 210 - state.therm * 40;
    const core = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR);
    core.addColorStop(0, `hsla(${hue},85%,70%,0.75)`);
    core.addColorStop(1, `hsla(${hue},85%,70%,0.00)`);
    ctx.fillStyle = core;
    ctx.beginPath();
    ctx.arc(cx, cy, coreR, 0, Math.PI * 2);
    ctx.fill();

    // Shield Layers
    for (let i = 0; i < state.layers; i++) {
      const r = scaleRadius(coreR + 12 + i * 11);
      const a = state.opacity * (0.85 - i * 0.07);
      ctx.strokeStyle = `rgba(90,160,255,${a})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Render Hits
    const newHits: Hit[] = [];
    hits.forEach(hh => {
      const dx = cx - hh.x;
      const dy = cy - hh.y;
      const d = Math.max(0.0001, Math.hypot(dx, dy));
      const step = 0.7 + state.hitIntensity * 1.3;
      
      const updatedHit = {
        x: hh.x + (dx / d) * step,
        y: hh.y + (dy / d) * step,
        r: hh.r + 0.55,
        life: hh.life - 0.012,
      };

      ctx.strokeStyle = 'rgba(180,180,180,0.65)';
      ctx.beginPath();
      ctx.arc(updatedHit.x, updatedHit.y, 2 + updatedHit.r * 0.2, 0, Math.PI * 2);
      ctx.stroke();

      // Check collision with shields
      const dist = Math.hypot(updatedHit.x - cx, updatedHit.y - cy);
      let absorbed = false;
      
      for (let i = state.layers - 1; i >= 0; i--) {
        const rr = scaleRadius(coreR + 12 + i * 11);
        if (dist <= rr + 2 && dist >= rr - 2) {
          state.reserve = Math.min(220, state.reserve + 0.5);
          ctx.strokeStyle = 'rgba(120,190,255,0.9)';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(cx, cy, rr, 0, Math.PI * 2);
          ctx.stroke();
          absorbed = true;
          break;
        }
      }

      if (!absorbed && updatedHit.life > 0) {
        newHits.push(updatedHit);
      }
    });

    onHitsUpdate(newHits);

    // Side indicators
    ctx.strokeStyle = 'rgba(160,180,210,0.35)';
    for (let i = 0; i < 3; i++) {
      const y = cy - 40 + (i * 18);
      const len = 40 + Math.sin(state.tickCount / 30 + i) * 22;
      ctx.beginPath();
      ctx.moveTo(cx - 60, y);
      ctx.lineTo(cx - 60 + len, y + Math.random() * 2 - 1);
      ctx.stroke();
    }
  }, [state, hits, onHitsUpdate, scaleRadius]);

  return (
    <div id="miniBox" className="rounded-[10px] border border-[rgba(200,210,230,0.3)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass-sm backdrop-blur-glass-sm">
      <canvas 
        ref={canvasRef} 
        id="miniCanvas"
        className="block h-[160px] w-full rounded-lg bg-[rgba(255,255,255,0.9)]"
        data-testid="canvas-shield"
      />
      <div id="miniLegend" className="mt-1.5 text-[11px] leading-relaxed" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
        • Shield rings (bright minimal) absorb blips → reserve trickle.
      </div>
    </div>
  );
}
