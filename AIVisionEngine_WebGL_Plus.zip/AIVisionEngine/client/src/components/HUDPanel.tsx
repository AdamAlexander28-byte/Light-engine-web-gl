import type { LightState } from '@shared/schema';

interface HUDPanelProps {
  state: LightState;
}

function MetricBar({ percentage, label }: { percentage: number; label: string }) {
  const color = 
    percentage < 60 ? 'rgb(62, 189, 118)' : 
    percentage < 85 ? 'rgb(255, 179, 71)' : 
    'rgb(255, 95, 87)';

  return (
    <div className="mt-1.5 h-2 overflow-hidden rounded-md bg-black/[0.06]">
      <div
        className="h-full transition-all duration-300 ease-out"
        style={{ width: `${Math.max(0, Math.min(100, percentage))}%`, background: color }}
        aria-hidden="true"
      />
    </div>
  );
}

function Pill({ children, testId }: { children: React.ReactNode; testId?: string }) {
  return (
    <span 
      className="inline-block rounded-full border border-[rgba(180,190,210,0.4)] bg-[rgba(255,255,255,0.25)] px-2 py-1 text-[11px]" 
      style={{ color: 'rgb(14, 26, 43)' }}
      data-testid={testId}
    >
      {children}
    </span>
  );
}

export function HUDPanel({ state }: HUDPanelProps) {
  const reservePercentage = (state.reserve / 2.2);
  const thermPercentage = state.therm * 100;
  const modePercentage = state.lowPower ? 33 : 85;

  return (
    <div>
      <h3 className="mb-2.5 mt-1.5 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>HUD</h3>
      
      {/* Reserve */}
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-sm">Reserve</span>
        <Pill testId="text-reserve">{state.reserve.toFixed(1)}</Pill>
      </div>
      <MetricBar percentage={reservePercentage} label="Reserve" />

      {/* Thermal */}
      <div className="mb-1.5 mt-1.5 flex items-center justify-between">
        <span className="text-sm">Thermal</span>
        <Pill testId="text-thermal">{Math.round(state.therm * 100)}%</Pill>
      </div>
      <MetricBar percentage={thermPercentage} label="Thermal" />

      {/* Mode */}
      <div className="mb-1.5 mt-1.5 flex items-center justify-between">
        <span className="text-sm">Mode</span>
        <Pill testId="text-mode">{state.lowPower ? 'LOW-POWER' : 'FULL'}</Pill>
      </div>
      <MetricBar percentage={modePercentage} label="Mode" />
    </div>
  );
}
