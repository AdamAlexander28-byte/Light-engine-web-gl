import { useEffect, useState, useRef, useCallback } from 'react';
import { LightLoader } from '../components/LightLoader';
import { GlassPanel } from '../components/GlassPanel';
import { HUDPanel } from '../components/HUDPanel';
import { ShieldControls } from '../components/ShieldControls';
import { ModularActivation } from '../components/ModularActivation';
import { LayerStack } from '../components/LayerStack';
import { ShieldCanvas } from '../components/ShieldCanvas';
import { SwitchFieldCanvas } from '../components/SwitchFieldCanvas';
import { AngleZoomCanvas } from '../components/AngleZoomCanvas';
import { TextRuntime } from '../components/TextRuntime';
import { useLightState } from '../hooks/useLightState';
import type { Hit } from '@shared/schema';

export default function LightViz() {
  const { state, updateState, moduleState, activateModule } = useLightState();
  const [hits, setHits] = useState<Hit[]>([]);
  const [channels, setChannels] = useState<number[]>(Array.from({ length: 10 }, () => Math.random()));
  const [throughput, setThroughput] = useState(0);
  const animationFrameRef = useRef<number>();
  const tpCharsRef = useRef(0);
  const tpLastRef = useRef(performance.now());

  const spawnHit = useCallback(() => {
    const w = 800;
    const h = 160;
    const edge = Math.floor(Math.random() * 4);
    let x = 0, y = 0;
    if (edge === 0) { x = 0; y = Math.random() * h; }
    if (edge === 1) { x = w; y = Math.random() * h; }
    if (edge === 2) { x = Math.random() * w; y = 0; }
    if (edge === 3) { x = Math.random() * w; y = h; }
    setHits(prev => [...prev, { x, y, r: 1, life: 1.0 }]);
  }, []);

  const aiRemap = useCallback(() => {
    setChannels(current => {
      const next: number[] = [];
      for (let i = 0; i < current.length; i++) {
        next.push(current[i]);
        next.push((current[i] + current[(i + 1) % current.length]) / 2);
      }
      return next.slice(0, 10).map(v => (v * 0.7 + Math.random() * 0.3));
    });
  }, []);

  const stepOnce = useCallback(() => {
    const cost = state.lowPower ? 0.25 : 0.65;
    const leak = 0.18;
    const recover = 0.12 + state.layers * 0.02;
    
    updateState({
      reserve: Math.max(0, Math.min(220, state.reserve - cost - leak + recover)),
      therm: Math.max(0.25, Math.min(1.0, state.therm - cost * 0.002 + 0.0018)),
      tickCount: state.tickCount + 1,
    });

    // Spawn hits
    if (Math.random() < state.hitIntensity * 0.6) {
      spawnHit();
    }

    // Update throughput
    if (Math.random() < 0.6) {
      const chars = `tick ${state.tickCount} :: reserve=${state.reserve.toFixed(1)} therm=${Math.round(state.therm * 100)}% layers=${state.layers}`.length;
      tpCharsRef.current += chars;
    }
    
    const now = performance.now();
    if (now - tpLastRef.current > 1000) {
      setThroughput(tpCharsRef.current);
      tpCharsRef.current = 0;
      tpLastRef.current = now;
    }
  }, [state, updateState, spawnHit]);

  const tick = useCallback(() => {
    if (!state.running) return;
    
    if (state.tickCount % 15 === 0) {
      aiRemap();
    }
    
    stepOnce();
    animationFrameRef.current = requestAnimationFrame(tick);
  }, [state.running, state.tickCount, aiRemap, stepOnce]);

  useEffect(() => {
    if (state.running) {
      animationFrameRef.current = requestAnimationFrame(tick);
    }
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [state.running, tick]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      
      if (k === ' ') {
        e.preventDefault();
        updateState({ running: !state.running });
        return;
      }
      if (k === '1') {
        updateState({ layersOn: { ...state.layersOn, shield: !state.layersOn.shield } });
      }
      if (k === '2') {
        updateState({ layersOn: { ...state.layersOn, switch: !state.layersOn.switch } });
      }
      if (k === '3') {
        updateState({ layersOn: { ...state.layersOn, zoom: !state.layersOn.zoom } });
      }
      if (k === 'z') {
        updateState({ quality: 'base' });
      }
      if (k === 'x') {
        updateState({ quality: 'zoom' });
      }
      if (k === 'c') {
        updateState({ quality: 'range' });
      }
      if (k === '+') {
        updateState({ layers: Math.min(8, state.layers + 1) });
      }
      if (k === '-') {
        updateState({ layers: Math.max(1, state.layers - 1) });
      }
      if (k === '[') {
        updateState({ hitIntensity: Math.max(0, state.hitIntensity - 0.05) });
      }
      if (k === ']') {
        updateState({ hitIntensity: Math.min(1, state.hitIntensity + 0.05) });
      }
      if (k === 'o') {
        updateState({ lowPower: !state.lowPower });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state, updateState]);

  return (
    <>
      <LightLoader />
      
      {/* Environment Shadow */}
      <div 
        className="pointer-events-none fixed inset-0"
        style={{
          background: 'radial-gradient(circle at 50% -20%, rgba(0,0,0,0.06) 0%, rgba(0,0,0,0) 70%)',
        }}
      />

      {/* Main Container */}
      <div 
        className="min-h-screen overflow-hidden"
        style={{
          background: 'linear-gradient(to top, rgb(255, 255, 255), rgb(237, 244, 255))',
          fontFamily: 'Segoe UI, system-ui, sans-serif',
          color: 'rgb(14, 26, 43)',
        }}
      >
        {/* Header */}
        <header 
          className="border-b border-[rgba(200,210,230,0.4)] bg-[rgba(255,255,255,0.25)] p-2.5 shadow-glass backdrop-blur-glass-sm"
        >
          <h1 className="m-0 text-lg font-semibold tracking-wide" style={{ color: 'rgb(14, 26, 43)' }}>
            .LIGHT — Shield + Switch-Field + Angle Zoom
          </h1>
        </header>

        {/* Main Grid */}
        <main 
          className="box-border grid gap-3 overflow-hidden p-3"
          style={{
            gridTemplateColumns: '320px 1fr 360px',
            gridTemplateRows: 'auto 1fr auto',
            gridTemplateAreas: '"left title right" "left center right" "footer footer footer"',
            height: 'calc(100vh - 56px)',
          }}
        >
          {/* Left Panel - HUD + Controls */}
          <GlassPanel 
            className="overflow-auto" 
            style={{ gridArea: 'left' }} 
            ariaLabel="HUD and Controls"
          >
            <HUDPanel state={state} />
            <ShieldControls
              state={state}
              onUpdate={updateState}
              onStart={() => updateState({ running: true })}
              onPause={() => updateState({ running: false })}
              onStep={() => { if (!state.running) stepOnce(); }}
            />
            <ModularActivation
              moduleState={moduleState}
              onActivate={activateModule}
            />
            <LayerStack state={state} onUpdate={updateState} />
          </GlassPanel>

          {/* Title */}
          <GlassPanel 
            className="text-center" 
            style={{ gridArea: 'title' }}
            id="title"
          >
            <h3 className="mb-2.5 mt-1.5 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
              Text Runtime • Shield • Switch-Field • Zoom
            </h3>
            <div className="text-xs" style={{ color: 'rgba(0, 0, 0, 0.55)' }}>
              White-morning glass view — dawn light reflects from each layer. Tap panels to cast light gloss.
            </div>
          </GlassPanel>

          {/* Center - Text Runtime */}
          <GlassPanel 
            className="overflow-hidden"
            style={{ 
              gridArea: 'center',
              display: 'grid',
              gridTemplateRows: 'auto 1fr',
              gap: '10px',
            }}
          >
            <TextRuntime state={state} throughput={throughput} />
          </GlassPanel>

          {/* Right - Visualizations */}
          <GlassPanel 
            className="overflow-y-auto overflow-x-hidden"
            style={{ gridArea: 'right' }}
            ariaLabel="Visual Layers"
          >
            <h3 className="mb-2.5 mt-1.5 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
              Mini Animation Box
            </h3>
            <ShieldCanvas state={state} hits={hits} onHitsUpdate={setHits} />

            <h3 className="mb-2.5 mt-3 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
              Switch-Field (360°)
            </h3>
            <SwitchFieldCanvas state={state} />

            <h3 className="mb-2.5 mt-3 text-base font-semibold" style={{ color: 'rgb(14, 26, 43)' }}>
              Angle Zoom (0–9)
            </h3>
            <AngleZoomCanvas state={state} channels={channels} />
          </GlassPanel>

          {/* Footer */}
          <div
            id="footer"
            className="rounded-[10px] border-t border-[rgba(200,210,230,0.4)] bg-[rgba(255,255,255,0.25)] p-2 text-center text-xs backdrop-blur-glass-sm"
            style={{ 
              gridArea: 'footer',
              color: 'rgba(0, 0, 0, 0.55)',
            }}
          >
            .LIGHT — Swedish dawn edition • Shield + Switch-Field + Zoom • © 2025
          </div>
        </main>

        {/* Responsive Styles */}
        <style>{`
          @media (max-width: 1024px) {
            main {
              grid-template-columns: 1fr !important;
              grid-template-areas: 
                "title"
                "left"
                "center"
                "right"
                "footer" !important;
              height: auto !important;
            }
            body {
              overflow: auto !important;
            }
          }
          
          /* Custom scrollbar for right panel */
          [aria-label="Visual Layers"] {
            scrollbar-width: thin;
            scrollbar-color: rgba(140,180,220,0.3) transparent;
          }
          
          [aria-label="Visual Layers"]::-webkit-scrollbar {
            width: 8px;
          }
          
          [aria-label="Visual Layers"]::-webkit-scrollbar-thumb {
            background: rgba(140,180,220,0.4);
            border-radius: 8px;
          }
          
          [aria-label="Visual Layers"]::-webkit-scrollbar-thumb:hover {
            background: rgba(120,160,200,0.6);
          }
        `}</style>
      </div>
    </>
  );
}
