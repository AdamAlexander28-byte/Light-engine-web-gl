// Minimal offline cache (optional). Uncomment registration in app.js if desired.
const CACHE = 'light-swedishdawn-v1';
const ASSETS = [
  '/', '/index.html', '/styles.css', '/app.js', '/icons/favicon.svg'
];
self.addEventListener('install', e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));
});
self.addEventListener('fetch', e=>{
  e.respondWith(caches.match(e.request).then(r=> r || fetch(e.request)));
});
